// app/(client)/layout.tsx
import type { ReactNode } from "react";

export default function ClientAreaLayout({ children }: { children: ReactNode }) {
  return <>{children}</>;
}