export type CartItem = {
  id: string;
  name: string;
  price: number;
  image?: string;
  quantity: number;
};

export type CartState = {
  items: CartItem[];
  addItem: (item: CartItem) => void;   // ✅ nome correto
  remove: (id: string) => void;
  updateQty: (id: string, qty: number) => void;
  clear: () => void;
  clearCart: () => void;
};
