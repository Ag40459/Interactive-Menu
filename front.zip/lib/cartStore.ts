"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { CartItem as OldCartItem, CartState as OldCartState } from "./types";

// Mantém o mesmo shape que seu código já usa:
type CartItem = OldCartItem & { quantity: number };

type CartState = Omit<OldCartState, "items"> & {
  items: CartItem[];
  total?: () => number; // opcional, se quiser usar
};

const useCartStore = create<CartState>()(
  persist<CartState>(
    (set, get) => ({
      items: [],

      addItem: (item: CartItem) =>
        set((state) => {
          const idx = state.items.findIndex((it) => it.id === item.id);
          const inc = item.quantity ?? 1;

          if (idx >= 0) {
            const copy = state.items.slice();
            copy[idx] = {
              ...copy[idx],
              quantity: (copy[idx].quantity ?? 0) + inc,
            };
            return { items: copy };
          }

          return {
            items: [
              ...state.items,
              { ...item, quantity: item.quantity ?? 1 },
            ],
          };
        }),

      remove: (id: string) =>
        set((state) => ({
          items: state.items.filter((it) => it.id !== id),
        })),

      updateQty: (id: string, qty: number) =>
        set((state) => ({
          items: state.items
            .map((it) => (it.id === id ? { ...it, quantity: qty } : it))
            .filter((it) => (it.quantity ?? 0) > 0),
        })),

      clear: () => set({ items: [] }),
      clearCart: () => set({ items: [] }), // alias usado pela página do carrinho

      total: () =>
        get().items.reduce(
          (acc, it) => acc + (it.price ?? 0) * (it.quantity ?? 0),
          0
        ),
    }),
    {
      name: "cd-cart-v1",
      storage: createJSONStorage(() => localStorage),
      version: 1,
      // ❌ removido o partialize para evitar erro de tipos
    }
  )
);

export default useCartStore;